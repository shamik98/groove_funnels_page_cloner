const webpack = require("webpack");
const path = require('path');
const CopyPlugin = require('copy-webpack-plugin');
const srcDir = '../src/';

module.exports = {
    entry: {
        bootstraptagsinput: path.join(__dirname, srcDir + 'bootstraptagsinput.js'),
        helper: path.join(__dirname, srcDir + 'helper.js'),
        background: path.join(__dirname, srcDir + 'background.js'),
        common: path.join(__dirname, srcDir + 'common.js'),
        config: path.join(__dirname, srcDir + 'config.json'),
        login: path.join(__dirname, srcDir + 'login.js'),
        changepassword: path.join(__dirname, srcDir + 'changepassword.js'),
        forgotpass: path.join(__dirname, srcDir + 'forgot-pass.js'),
        content: path.join(__dirname, srcDir +'content.js')
    },
    output: {
        path: path.join(__dirname, '../dist/js'),
        filename: '[name].js'
    },
    optimization: {
        splitChunks: {
            name: 'vendor',
            chunks: "initial"
        }
    },
    module: {
        rules: [
            {
                test: /\.tsx?$/,
                use: 'ts-loader',
                exclude: /node_modules/
            },
            {
                test: /\.exec\.js$/,
                use: [ 'script-loader' ],
                exclude: /node_modules/
            }
        ]
    },
    resolve: {
        extensions: ['.ts', '.tsx', '.js', '.json']
    },
    plugins: [
        // exclude locale files in moment
        new webpack.IgnorePlugin(/^\.\/locale$/, /moment$/),
        new CopyPlugin([
            { from: '.', to: '../' }
          ],
          {context: 'public' }
        ),
    ]
};
