var $ = jQuery = require('jquery');
const helper = require("./helper.js");
const configStore =  require('../public/kyubiSettings.json')
$(document).ready(function(){

  $.getJSON("kyubiSettings.json", async function (result) {
    
    if(result.extId == "5faa3cf4a4a7967e5fe84b9b"){
      console.log("----------------------------",);
      $('.morePower').css('display','block');
    }else{
      $('.morePower').css('display','none');
    }
  });


  helper.checkAuthStatus();

  dynamicHTMLContent();

  $("#logout").on("click", function (e) {
    e.preventDefault();
    // console.log("Logout Clicked");
    console.log("Logout Clicked");
    chrome.storage.sync.get(["store"], function (res) {
      // console.log("res :::: from logout :::: ", res.store.user);
      if (helper.checkAccessToken(res)) {
        logoutPP(
          res.store.user.token,
          configStore.clearSubscriptionObjectURL,
          res.store.user.email,
          configStore.extId,
          res.store.user.deviceID
        );
      } else {
      }
    });
  });

  function logoutPP(token, logoutURL, email, extensionId, deviceID) {
    // console.log("infos in logout function ::: ", token, "\n", email, "\n", extensionId, "\n", deviceID);
    fetch(logoutURL, {
      method: "POST", // *GET, POST, PUT, DELETE, etc.
      mode: "cors", // no-cors, cors, *same-origin
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json"
      },
      body: JSON.stringify({ email: email, extId: extensionId }),
    })
      .then((response) => response.json())
      .then((res) => {
        console.log("api call from kyubi : ", res);
        if (res.status) {
          chrome.storage.sync.remove("store", function () {
            //console.log("Or Its clicking here");
            window.location.replace("../login.html");
          });
        }
      })
      .catch((err) => {
        chrome.storage.sync.remove("store", function () {
          //console.log("Or Its clicking here");
          window.location.replace("../login.html");
        });
      })
      .catch((err) => {});
  }


  $("#clr_acnt").click(function(e){
    e.preventDefault();
    $(".popup_overlay").remove();
    $('body').append('<div class="popup_overlay close_button"><button id= "close">'+
    '<img src="./assets/clear-white-18dp.svg" alt="" ></button><span>To cancel your account please email us at <a href="mailto:'+
    configStore.mailTo
    +'" style=" text-decoration: underline;">'
    +configStore.mailTo+'</a></span></div>');
    $(".popup_overlay").css("display", "block");
  })

  $(document).on('click' , "#close" , function(e){
    e.preventDefault();
    // console.log("close............")
    $(".popup_overlay").fadeOut();
    setTimeout(function(){
    $(".popup_overlay").remove();
    },400);
    // $(document).remove('.popup_overlay');
  })


if(configStore.mailTo == null || configStore.mailTo == ""){
  $("#clr_acnt").hide();
}else{
  $("#clr_acnt").show();
}
  
    // $('#logout').on('click', function(e) {
    //     e.preventDefault()
    //     //console.log("Logout Clicked");
    //         chrome.storage.sync.remove(('store'), function() {
    //             //console.log("Or Its clicking here");
    //             window.location.replace("../login.html");
    //         });
    // });

    // $("#clr_acnt").click(function(e){
    //   e.preventDefault();
    //   $(".popup_overlay").remove();
    //   $('body').append('<div class="popup_overlay close_button"><button id= "close"><img src="./assets/clear-white-18dp.svg" alt="" ></button><span>To cancel your account please email us at <a href="mailto:support@tier5.us" style=" text-decoration: underline;">support@tier5.us</a></span></div>');
    //   $(".popup_overlay").css("display", "block");
    // })

    // $(document).on('click' , "#close" , function(e){
    //   e.preventDefault();
    //   // console.log("close............")
    //   $(".popup_overlay").fadeOut();
    //   setTimeout(function(){
    //   $(".popup_overlay").remove();
    //   },400);
    //   // $(document).remove('.popup_overlay');
    // })
    
    $("#copyFunnel").click(function () {
      // console.log("Copy funnel clicked.")
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        // console.log("tabs : ",tabs);
        chrome.tabs.sendMessage(tabs[0].id, { msg: "copy" }, function (response) {
          // console.log("get response ::: ",response.response )
          chrome.storage.local.set({ groovesData: response.response }, function () {
            // console.log("data is setting in storage.")
            if (chrome.runtime.error) {
              // console.log("Runtime error.");
            }
          });
        });
      });
    });
    
    $("#pasteFunnel").click(function () {
      // console.log("paste funnel is clicked.")
      chrome.storage.local.get('groovesData', function (items) {
        // console.log("items : ", items);
        if (!chrome.runtime.error) {
          chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(
              tabs[0].id,{ msg: "paste", payload: items });
          });
        }
      });
    });


    // Menu
    $(".triggerMenu").click(function () {
      $(this).parent().toggleClass("open");
    });
    $(document).click(function (event) {
      if ($(event.target).closest(".triggerMenu, .menuHeader").length === 0) {
        $(".menuNav ").removeClass("open");
      }
    });
    // Menu --- END
});

const dynamicHTMLContent = () => {
  $.getJSON("kyubiSettings.json", function (result) {
    /* Placing header logo */
    $("#dynamicLogo").html(
      '<img src="' +
        result.logo.primary_logo +
        '" alt="Logo" style="max-height:50px; max-width:135px">'
    );
    $("#appTitle").text(result.appName);
    if (result.loader.preLoader)
      $("#overlay").html(
        '<img src="' +
          result.loader.preLoader +
          '" alt = "" height="34" width="34">'
      );
    else
      $("#overlay").html(
        '<img src="./images/loader.gif" alt = "" height="34" width="34">'
      );
    /* Change appname*/
    if (result.youtubeLink) {
      $("#video").attr("src", result.youtubeLink);
    } else {
      $("#video").attr("src", "");
    }
    /* Placing footer */
    if (result.footer.showFooter) {
      // console.log("result.footer.showFooter true : ", result.footer.showFooter);
      if (result.footer.poweredBy.willBeDisplayed) {
        if (result.footer.poweredBy.url) {
          $("#poweredby").attr("href", result.footer.poweredBy.url);
          if (result.footer.poweredBy.url == "#")
            $("#poweredby").removeAttr("target");
        } else {
          $("#poweredby").attr("href", "");
          $("#poweredby").removeAttr("target");
        }
        if (result.footer.poweredBy.label)
          $("#poweredby").html(result.footer.poweredBy.label);
        else {
          $("#poweredby").html("");
          $("#and").hide();
        }
      } else {
        $("#poweredby").attr("href", "");
        $("#poweredby").html("");
        $("#and").hide();
      }

      if (result.footer.partnership.willBeDisplayed) {
        if (result.footer.partnership.url) {
          $("#partnership").attr("href", result.footer.partnership.url);
          if (result.footer.partnership.url == "#")
            $("#partnership").removeAttr("target");
        } else {
          $("#partnership").attr("href", "");
          $("#partnership").removeAttr("target");
        }
        if (result.footer.partnership.label)
          $("#partnership").html(result.footer.partnership.label);
        else {
          $("#partnership").html("");
          $("#and").hide();
        }
      } else {
        $("#partnership").attr("href", "");
        $("#partnership").html("");
        $("#and").hide();
      }

      if (result.footer.officialGroup.willBeDisplayed) {
        if (result.footer.officialGroup.url) {
          $("#group").attr("href", result.footer.officialGroup.url);
        } else {
          $("#group").attr("href", "");
          $("#group").html("");
        }
      } else {
        $("#group").attr("href", "");
        $("#group").html("");
      }

      if (result.footer.chatSupport.willBeDisplayed) {
        if (result.footer.chatSupport.url) {
          $("#chat").attr("href", result.footer.chatSupport.url);
        } else {
          $("#chat").attr("href", "");
          $("#chat").html("");
        }
      } else {
        $("#chat").attr("href", "");
        $("#chat").html("");
      }
    } else {
      $(".cf_footer").html("");
    }
  });
};
