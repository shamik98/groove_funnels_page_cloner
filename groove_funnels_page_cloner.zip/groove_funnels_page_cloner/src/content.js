/**
 * CONTENT SCRIPT
 * @author Tier5 <work@tier5.us>
 * @copyright All Legal authorities to Tier5 Technologies Pvt. Ltd.
 * Developer: Susmita
 * Moderator: Jit
 * @version 1
 */

 const $ = jQuery = require('jquery');
 require('jquery-toast-plugin');
 const helper = require("./helper.js");
 const kyubiSettings = require('../public/kyubiSettings.json')
 let data = {};
 let base64Image;
 $(document).ready(function(){
   // console.log("doc is ready.")
   chrome.storage.sync.get(['store'], async function (res) {
     // console.log("helper.checkAccessToken(res) : ", helper.checkAccessToken(res));
     if (helper.checkAccessToken(res)) {
       // console.log("gf,jfldludyludy");
 
       base64Image = await base64(kyubiSettings.logo.medium_icon);
 
       if($('div[data-gp-page-id]').length){
        console.log("befoe the set timeout function");
         setTimeout(function(){
          console.log("Inside set timeout fucntion");
         // console.log("gf,jfldludyludy",base64);
         $(".jq-toast-single").removeClass("groove");
         console.log("After removing the groove class");
           toast(
             "Groove page can be copied" +
             '<div id="copySC" style = "margin-left : 1px"><img class="_2yaw img" aria-hidden="true" src="'+chrome.runtime.getURL("assets/Copy.png")+'" alt="" style=" max-height: 13px; max-width: 13px;"></div>',
             "",
             2
           );
           console.log("after the toast fucntion");
             $(".jq-toast-single").addClass("groove");
             $(".groove").css("background-image", "url(" + base64Image + ")");
             bgImage(base64Image);
           },1000)
       }
 
     
       $('#copySC').click(function(){
         // console.log("copy button in notification is clicked...");
         data=  {
           pageTitle: $('title').text(),
           pageContent: $('#blocks-container').html(),
           // pageCon: $('.containerWrap').html(),
           htmlAttr: $('html').attr("style"),
           customCss: $('#custom-css').text()//id = IE-warning-style  //section-block  //custom-css //global-styles
             
         }
           chrome.storage.local.set({ groovesData: data }, function () {
             if (chrome.runtime.error) {
               // console.log("Runtime error.");
             }
           });
       })
       chrome.runtime.onMessage.addListener(
         async function(request, sender, sendResponse) {
         console.log('CLIKED AND MESSAGE IS:', request.msg);
           if (request.msg == "copy"){
             console.log("Coppied.");
           data=  {
               pageTitle: $('title').text(),
               pageContent: $('#blocks-container').html(),  //id=page-container
               // pageCon: $('.containerWrap').html(),
               htmlAttr: $('html').attr("style"),
               customCss: $('#custom-css').text()
             }
             console.log("data.pageContent : ", data);
             // if(data.pageContent || data.pageCon){
               if ($('#page-container').length){
               sendResponse({response:data });
               base64Image = await base64(kyubiSettings.logo.medium_icon);
                 console.log("base64Image : ", base64Image);
               setTimeout(function(){
                   $(".jq-toast-single").removeClass("groove");
                   toast(
                     "Groove Funnel page has copied",
                     "Don't refresh the page",
                     1
                     );
                       $(".jq-toast-single").addClass("groove");
                       $(".groove").css("background-image", "url(" + base64Image + ")");
                       bgImage(base64Image);
                 },1000)
             }
           }
           if(request.msg == "paste"){
             $('title').text(request.payload.groovesData.pageTitle);
             $("#gp_builder_frameContainer iframe").contents().find('body').find('#page-container').children().eq(0).html(request.payload.groovesData.pageContent);
             // $("#gp_builder_frameContainer iframe").contents().find('body').find('html').attr("style",request.payload.groovesData.htmlAttr);
             // $("#gp_builder_frameContainer iframe").contents().find('head').find('#custom-css').text(request.payload.groovesData.customCss);
             setTimeout(function(){
               $(".jq-toast-single").removeClass("groove");
               toast(
                 "Paste to groove funnel editor successfully.",
                 "Don't refresh the page",
                 1
               ); 
                   $(".jq-toast-single").addClass("groove");
                   $(".groove").css("background-image", "url(" + base64Image + ")");
                   bgImage(base64Image);
             },1000)
             setTimeout(() => {
                 window.isFreeUser = true;
                 window[1].isFreeUser = true;
                 var scInterval = setInterval(saveFunction, 500);
                 function saveFunction() {
                     var saved = $('#btn_save_site').text().trim();
                     console.log("saved ::: ", saved);  
                     $('#btn_save_site').click();
                     if (saved == 'Saved') {
                       // console.log("not saved");
                       clearInterval(scInterval);
                       setTimeout(() => {
                         window.location.reload();
                       },1500);
                     }
                 }
             },5000);
           }
         });
       }
     });
 });   
 /**
  * FUNCTION FOR SHOW TOAST MESSAGE IN FACEBOOK
  * @param {String} heading Title of the toast
  * @param {String} body Description to show in the toast
  * @param {Number} type Toast type [Error, Success, Info, Warning]
  * @param {Boolean} isSticky Sticky toast or auto hide
  */
 
     function toast(heading, body, type = 1, isSticky = false) {
       var toastType = ["error", "success", "info", "warning"];
       const options = {
         heading: heading,
         text: body,
         showHideTransition: "slide",
         icon: toastType[type],
         position: "bottom-left",
         hideAfter : 6000, 
       };
       if(isSticky) {
         options.hideAfter = isSticky;
       }
       return $.toast(options);
       // return new Toast(options);
     };
 
 
     const base64 = async (logo) => {
       // console.log("logo : ", logo);
       return new Promise((resolve) => {
         try {
           var xhr = new XMLHttpRequest();
           xhr.open("GET", chrome.runtime.getURL(logo), true);
           xhr.responseType = "blob";
           xhr.onload = function (e) {
             var reader = new FileReader();
             reader.onload = async function (event) {
               var base64Img = await event.target.result;
     
               resolve(base64Img);
             };
             var file = this.response;
             reader.readAsDataURL(file);
           };
           xhr.send();
         } catch (e) {   
           resolve(false); 
         }
       });
     };
 
     const bgImage = (toast) => {
       $(".jq-toast-single").append(
         `<style>.jq-toast-single:after {
         background-image:url("` +
           toast +
           `")
     }
     </style>`
       );
     };
    