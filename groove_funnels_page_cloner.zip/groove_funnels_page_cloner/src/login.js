const $ = (jQuery = require("jquery"));
const helper = require("./helper.js");
const configStore = require("../public/kyubiSettings.json");

chrome.storage.sync.get(["store"], function (res) {
  if (helper.checkAccessToken(res)) {
        window.location.href = "dashboard.html";
  }
});

$(document).ready(function () {
  $("#login").click(function (e) {
    e.preventDefault();
    //console.log("login button clicked.");
    //console.log("loginToCF function started");
    let email = $("#email").val();
    let password = $("#password").val();
    var errorMessage = "Please enter valid credentials";

    var mailregex = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
    if (email.length == 0) {
      $("#emailid").html("Provide email id please.");
      return;
    }
    if (!mailregex.test(email)) {
      $("#emailid").html("Put valid email id please.");
      // if (!$("#emailid").hasClass("error")) {
      //     $("#emailid").addClass("error")
      // }
      return;
    }
    // //console.log("Asdfasd asdxcas");
    else {
      //console.log("mail is valid");
      $("#emailid").html("");
    }
    if (password.length == 0) {
      $("#i_password").html("Provide password please.");
      return;
    }
    // //console.log("Asdfasd asdxcas");
    else {
      //console.log("mail is valid");
      $("#i_password").html("");
    }
    $(".cf_overlay").css("display", "block");
    $(".cf_overlay").css("background", "rgb(57 157 240 / 0.8)");
    $.getJSON("kyubiSettings.json", function (result) {
      // console.log("result ::: ", result.loginURL, result.extId)
      chrome.storage.sync.get("subscription", function (res) {
        console.log("res subscription ::: ", res);
        getDeviceId(
          email,
          password,
          result.extId,
          result.loginURL,
          res.subscription
        );
      });
    });
  });
});

const loginToCF = function (
  email,
  password,
  extensionId,
  loginURL,
  deviceID,
  confirmLogout,
  subscription
) {
//   console.log(
//     " arg of loginToCF ::: ",
//     email,
//     password,
//     extensionId,
//     loginURL,
//     deviceID,
//     confirmLogout,
//     subscription
//   );
  fetch(loginURL, {
    method: "POST", // *GET, POST, PUT, DELETE, etc.
    mode: "cors", // no-cors, cors, *same-origin
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      email: email,
      password: password,
      extensionId: extensionId,
      deviceId: deviceID,
      confirmLogout: confirmLogout,
      subscription: subscription,
    }), // body data type must match "Content-Type" header
  })
    .then((response) => response.json())
    .then(async (res) => {
      if (res.status == true && res.token) {
        saveToken(email, res, deviceID);
      } else if (res.status && !res.token) {
        const ConfirmMsg = confirm(res.message);
        if (ConfirmMsg == true) {
          loginToCF(
            email,
            password,
            extensionId,
            loginURL,
            deviceID,
            true,
            subscription
          );
        } else {
          $(".cf_errMsglogin").removeAttr("style");
          $(".cf_errMsglogin").html(res.message);
          setTimeout(function () {
            $(".cf_errMsglogin").fadeOut();
          }, 4000);
        }
      } else {
        //console.log("Coming in else part")
        $(".cf_errMsglogin").removeAttr("style");
        $(".cf_errMsglogin").html(res.message);

        setTimeout(function () {
          $(".cf_errMsglogin").fadeOut();
        }, 4000);
      }
    })
    .catch((err) => {
      console.log("response got in err : ", err);
      $(".cf_errMsglogin").html(err);
      setTimeout(function () {
        $(".cf_errMsglogin").fadeOut();
      }, 6000);
    })
    .finally(function () {
      $(".cf_overlay").css("display", "none");
    });
};

const getDeviceId = function (
  email,
  password,
  extensionId,
  loginURL,
  subscription
) {
  var navigator_info = window.navigator;
  var screen_info = window.screen;
  var uid = navigator_info.mimeTypes.length;
  uid += navigator_info.userAgent.replace(/\D+/g, "");
  uid += navigator_info.plugins.length;
  uid += screen_info.height || "";
  uid += screen_info.width || "";
  uid += screen_info.pixelDepth || "";
  // console.log("uid: ", uid);
  // console.log(" arg of getDeviceId ::: ", email, password, extensionId, loginURL);
  loginToCF(email, password, extensionId, loginURL, uid, false, subscription);
};

function saveToken(email, resp, deviceID) {
//   console.log("args of saveToken method is ::: ", email, resp, deviceID);
  let store = {
    user: {
      email: email,
      token: resp.token,
      deviceID: deviceID,
      // password: password
    },
  };

  chrome.storage.sync.set({ store: store }, function () {
    chrome.storage.sync.get(["store"], function (res) {
      // console.log("res in storage store ::: ",res);
      // console.log("Checkig logged in already or not",!helper.checkAccessToken(res));
      if (helper.checkAccessToken(res)) {
        // $(".cf_overlay").css("display","none");
        //console.log(helper.checkAccessToken(res))
        chrome.storage.sync.get(["settings"], function (res) {
          //console.log("items",res.settings);
          if (res.settings != undefined && res.settings != null) {
            window.location.href = "funnels.html";
          } else {
            window.location.href = "dashboard.html";
          }
        });
      } else {
        window.location.href = "login.html";
      }
    });
  });
}
