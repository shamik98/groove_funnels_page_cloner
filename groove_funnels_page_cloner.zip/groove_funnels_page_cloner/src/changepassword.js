const $ = jQuery = require('jquery');
const url = require("./config.json")
const helper = require("./helper.js")
const configStore = require("../public/kyubiSettings.json");

$(document).ready(function() {
    $("#submitNewPassword").click(function(e) {
        e.preventDefault();
        //console.log(url.BASE_URL);
        //console.log("arreeyy button is working to");
        let old_password = $("#password").val();
        let new_password = $("#newpassword").val();
        let confirm_password = $("#repeatnewpassword").val();
        if (old_password.length == 0) {
            //console.log("oldlength is 0");
            $("#errormsg1").html("Please provide your old password.");
            return
        } else {
            $("#errormsg1").html("");
        }

        if (new_password.length == 0) {
            // //console.log("oldlength is 0");
            $("#errormsg2").html("Please provide a new password.");
            return
        } else {
            $("#errormsg2").html("");
        }

        if (old_password === new_password) {
            $("#errormsg2").html("Old password and new password should not be same.");
            return
        } else {
            $("#errormsg2").html("");
        }

        if (new_password !== confirm_password) {
            $("#errormsg3").html("New password and confirm new password should be same.");
            
            return
        } else {
            $("#errormsg3").html("");
        }

        // Getting accessToken from localStorage
        // Enable when login is being pushed to git
        chrome.storage.sync.get(["store"], function(res) {
            // console.log("res :::: from changePassword :::: ", res);
            if (helper.checkAccessToken(res)) {
                updatePwd( res.store.user.token, res.store.user.email, old_password, new_password, confirm_password );
            } else {
                //console.log("No access token found");
                $("#formContent").html("No access token found");
                $("#formContent").show();
                setTimeout(() => {
                    $("#formContent").hide();
                }, 3000);
            }
        });
    });
});

// Sending update password request to the server
const updatePwd = function( token,email, oldPwd, newPwd, cnewPwd) {
    // console.log("token : ", token)
    fetch(configStore.changePassURL, {
            method: "POST", // *GET, POST, PUT, DELETE, etc.
            mode: "cors", // no-cors, cors, *same-origin
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
                'Authorization': "KYUBI_" + token,
                'Access-Control-Allow-Origin': "*"
            },
            body: JSON.stringify({ 
                extensionId : configStore.extId,
                email: email,
                password: oldPwd,
                confirmNewPassword:cnewPwd,
                newPassword: newPwd 
            }), // body data type must match "Content-Type" header
            redirect: 'follow'
        }).then(response => response.json()).then(res => {
            // console.log("res ::: ", res)
            if (res.status == true) {
                // $("#errormsg3").html(res.data.message);
                chrome.storage.sync.get(['settings'], function (res) {
                    // console.log("items",res.settings);
                    if(res.settings!=undefined && res.settings!=null)
                    {
                        window.location.href='funnels.html';
                    }
                    else{
                        window.location.href='dashboard.html';
                    }
                });
            } else {
                $("#formContent").html(res.message);
                $("#formContent").show();
                setTimeout(() => {
                    $("#formContent").hide();
                }, 3000);
            }
            //console.log("Response ", res);
        })
        .catch(err => {
            //console.log(err.message);
        });
}