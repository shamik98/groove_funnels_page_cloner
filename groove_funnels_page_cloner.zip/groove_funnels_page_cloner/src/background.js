const helper = require("./helper.js");
const configStore = require("../public/kyubiSettings.json");
// console.log("config :: ", configStore.publicVapidKey);

// document.addEventListener("DOMContentLoaded", function () { 
//   console.log("DOM CONTENT LOADED")
//   if ('serviceWorker' in navigator) {
//    console.log("requesting permission")
//    Notification.requestPermission(function (result) {
//     console.log("result : ", result)
//     if (result === 'granted') {
//      sendFn().catch(e => console.error('EERR : ', e))
//     }
//    })
//   }
//  });

//  function urlBase64ToUint8Array(base64String) {
//   const padding = '='.repeat((4 - base64String.length % 4) % 4);
//   const base64 = (base64String + padding)
//    .replace(/-/g, '+')
//    .replace(/_/g, '/');

//   const rawData = window.atob(base64);
//   const outputArray = new Uint8Array(rawData.length);

//   for (let i = 0; i < rawData.length; ++i) {
//    outputArray[i] = rawData.charCodeAt(i);
//   }
//   return outputArray;
//  }

//  // Register the service worker
//  // Register Push
//  // Send the push
//  const sendFn = async () => {
//   // Register SErvice Worker
//   console.log("Registering service worker")
//   const register = await navigator.serviceWorker.register('./worker.js', {
//    scope: '/'
//   })

//   console.log('waiting for ready : ', register)
//   await navigator.serviceWorker.ready;

//   console.log('register service worker : ', register)

//   const subscription = await register.pushManager.subscribe({
//    userVisibleOnly: true,
//    applicationServerKey: urlBase64ToUint8Array(configStore.publicVapidKey)
//   })
//   console.log('Push registered..', subscription)

//   chrome.storage.sync.set({
//    subscription: JSON.parse(JSON.stringify(subscription))
//   }, function () {
//    // chrome.storage.sync.get(['subscription'], function(sub) {
//      console.log('sub : ', subscription)

//    //   // ycePorts.loginResponsePort.postMessage({"subscription": sub.subscription})
//    // })
//   })
//  }


chrome.tabs.onActivated.addListener(function (activeInfo) {
  setPopup();
});

chrome.tabs.onUpdated.addListener(function (activeInfo) {
  setPopup();
});


function setPopup() {
  chrome.storage.sync.get(['store'], function (res) {
    //console.log("res ::: ", res);
    //console.log("Checkig logged in already or not", helper.checkAccessToken(res));
    if (helper.checkAccessToken(res)) {
      chrome.action.setPopup({ popup: '../dashboard.html' });
    } else {
      chrome.action.setPopup({ popup: '../login.html' });
    }

  });
};


