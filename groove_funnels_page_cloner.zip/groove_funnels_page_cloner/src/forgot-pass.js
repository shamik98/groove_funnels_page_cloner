const $ = jQuery = require('jquery');
const url = require("./config.json");
const configStore = require("../public/kyubiSettings.json");
$(document).ready(function() {
    //console.log(url.BASE_URL);
    $("#forgotPass").click(function(e) {
        e.preventDefault();
        // alert("on submit comming");
        var email = $("#email").val();
        var mailregex = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
        if(email.length==0){
            $(".cf_errMsg").html("Provide your email id please.");
        }
        else if (!mailregex.test(email)) {
            $(".cf_errMsg").html("Put valid email id please.");
        }
        else {
            forgot(email);
        }
    });
});

const forgot = function(email) {
    fetch(configStore.forgotPassURL, {
        method: "POST", // *GET, POST, PUT, DELETE, etc.
        mode: "cors", // no-cors, cors, *same-origin
        headers: {
            "Content-Type": "application/json",
            "Accept": "application/json"
        },
        body: JSON.stringify({ email: email, extId:configStore.extId }) // body data type must match "Content-Type" header
    }).then(response => response.json()).then(res => {
        //console.log("response from server", res);
        if (res.status) {
            // //console.log("response from server", res)
            window.location.href = "../confirmation.html";
        } else {
            $("#wrongmail").html(res.message);
        }
    });
}